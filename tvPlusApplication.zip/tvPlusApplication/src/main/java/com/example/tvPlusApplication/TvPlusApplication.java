package com.example.tvPlusApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TvPlusApplication {

	public static void main(String[] args) {
		SpringApplication.run(TvPlusApplication.class, args);
	}

}
